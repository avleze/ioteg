En este directorio se encuentran los siguientes ficheros y directorios:

- Vídeo.mp4 - Consiste en un vídeo donde se visualiza parte del proceso de la recolección de datos donde se simulan varias caídas. La caída consiste en rodar en la cama y caer al suelo. A lo largo del mismo se puede observar el tipo de caída que estamos analizando y cómo los valores de los sensores pueden verse alterados por diferentes factores ajenos al evento caída que se quiere simular.

- FallEventType.xml - Es un fichero XML en el que se ha definido el tipo de evento caída para ser utilizado con la herramienta IoT-TEG. En este se incluye la propiedad "custom_behaviour" donde ha de indicarse la ruta absoluta del fichero donde se definen las reglas de comportamiento para el atributo de evento al que está asignado.

- AnálisisCaídas.ods - En esta hoja de cálculo se muestran los valores de la aceleración de cada uno de los sensores que forman parte del prototipo 1.0. En cada hoja se visualizan los valores de cada sensor (S1-S4) por separado, incluyendo una columna con los milisegundos, y la aceleración normalizada. Hay que destacar que estos sensores no están constantemente mandando información, de ahí que la cantidad de valores entre sensores sea diferente. En la hoja "Pruebas" se muestran los valores de los eventos generados utilizando los ficheros alojados en el directorio "CustomFiles". En estos ficheros se han definido las reglas de comportamiento de la aceleración en el momento de una caída de tipo rodar en la cama y caer al suelo.

- Falling into bed.txt - Contiene los valores originales obtenidos de los sensores (S1-S4) del prototipo 1.0.

- CustomFiles - Consiste en un directorio que contiene los ficheros 1, 2 y 3 donde se definen las reglas de comportamiento de la aceleración en el momento de una caída de tipo rodar en la cama y caer al suelo. En cada uno se ha variado los valores de algunas variables o de las propias reglas para llegar a conseguir unos eventos de prueba que simulen fielmente este comportamiento.

- EventosGenerados - Directorio que contiene los ficheros CSV con los valores de los eventos generados utilizando IoT-TEG y los ficheros que se encuentran en el directorio "CustomFiles". Los valores del fichero FallEventType1.csv siguen las reglas del fichero "CustomFiles/1", los del fichero FallEventType2.csv siguen las reglas del fichero "CustomFiles/2" y los del fichero FallEventType3.csv siguen las reglas del fichero "CustomFiles/3".


Para poder generar los eventos de prueba utilizando los ficheros que se incluyen en "CustomFiles" o cualquier otro que el usuario quiera definir, se tendrá que instalar previamente la herramienta IoT-TEG. En la página web http://ucase.uca.es/iot-teg se detallan los pasos para su instalación y uso.



